#ifndef UTIL_INTEGER_H_
#define UTIL_INTEGER_H_

bool checkInteger(double);
int asInteger(double);

#endif /* UTIL_INTEGER_H_ */
