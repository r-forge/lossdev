#ifndef JAGS_VERSION_H_
#define JAGS_VERSION_H_

extern "C" {
   char const * jags_version();
}

#endif /* JAGS_VERSION_H_ */
