#ifndef UTIL_INTEGER_H_
#define UTIL_INTEGER_H_

int asInteger(double);
int checkInteger(double, bool&);

#endif /* UTIL_INTEGER_H_ */
